package recuperatorio;

public class Arbol extends Planta implements Podable {

    private double alturaMaxima;

    public Arbol(String nombre, String ubicacion, String clima, double alturaMaxima) {
        super(nombre, ubicacion, clima);
        this.alturaMaxima = alturaMaxima;
    }

    @Override
    public String toString() {
        return "Arbol{" + "nombre: " + nombre + ", ubicacion: " + ubicacion + ", clima: " + clima + "alturaMaxima: " + alturaMaxima + "m}";
    }

    @Override
    public void podar() {
        System.out.println("Podando el arbol '" + nombre + "'");
    }

}
