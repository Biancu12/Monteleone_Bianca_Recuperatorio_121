package recuperatorio;

public class Test {

    public static void main(String[] args) {
        Jardin jardin = new Jardin();

        try {
            jardin.agregarPlanta(new Flor("Girasol", "Ala este", "Calido", Temporada.VERANO));
            jardin.agregarPlanta(new Flor("Margarita", "Ala oeste", "Arido", Temporada.PRIMAVERA));
            jardin.agregarPlanta(new Arbol("Sause", "Ala sur", "Calido", 20.3));
            jardin.agregarPlanta(new Arbol("Limonero", "Ala norte", "Calido", 3.2));
            jardin.agregarPlanta(new Arbusto("Rosas", "Ala este", "Calido", 10));
            jardin.agregarPlanta(new Arbusto("Jazmines", "Ala oeste", "Calido", 5));
            jardin.agregarPlanta(new Arbusto("Jazmines", "Ala oeste", "Calido", 5)); //Planta repetida
        } catch (PlantaRepetidaException e) {
            System.out.println("Error: " + e.getMessage());
        }

        System.out.println("..................................................................");

        jardin.mostrarPlantas();

        System.out.println("..................................................................");

        jardin.podarPlantas();
    }

}
