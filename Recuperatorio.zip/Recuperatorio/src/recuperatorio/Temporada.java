package recuperatorio;

public enum Temporada {
    PRIMAVERA,
    OTONIO,
    VERANO,
    INVIERNO
}
