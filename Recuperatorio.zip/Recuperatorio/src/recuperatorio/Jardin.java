package recuperatorio;

import java.util.ArrayList;
import java.util.List;

public class Jardin {

    private List<Planta> plantas;

    public Jardin() {
        plantas = new ArrayList<>();
    }

    public void agregarPlanta(Planta planta) {
        if (plantas.contains(planta)) {
            throw new PlantaRepetidaException();
        }
        plantas.add(planta);
    }

    public void mostrarPlantas() {
        System.out.println("Plantas en el jardin:");
        for (Planta planta : plantas) {
            System.out.println(planta);
        }
    }

    public void podarPlantas() {
        System.out.println("Podando plantas: ");
        for (Planta planta : plantas) {
            if (planta instanceof Podable podable) {
                podable.podar();
            } else {
                System.out.println("La planta no se puede podar");
            }
        }
    }

}
