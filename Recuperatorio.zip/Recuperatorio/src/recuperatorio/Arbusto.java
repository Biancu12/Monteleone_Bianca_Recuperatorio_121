package recuperatorio;

public class Arbusto extends Planta implements Podable {

    private int densidadFollaje;

    public Arbusto(String nombre, String ubicacion, String clima, int densidadFollaje) {
        super(nombre, ubicacion, clima);
        this.densidadFollaje = densidadFollaje;
    }

    @Override
    public String toString() {
        return "Arbusto{" + "nombre: " + nombre + ", ubicacion: " + ubicacion + ", clima: " + clima + "densidadFollaje: " + densidadFollaje + '}';
    }

    @Override
    public void podar() {
        System.out.println("Podando el arbusto '" + nombre + "'");
    }

}
