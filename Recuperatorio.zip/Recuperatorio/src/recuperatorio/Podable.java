package recuperatorio;

public interface Podable {

    public void podar();
}
